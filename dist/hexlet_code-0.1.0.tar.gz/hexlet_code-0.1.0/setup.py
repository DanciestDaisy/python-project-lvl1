# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/DanciestDaisy/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/DanciestDaisy/python-project-lvl1/actions)\n\nbrain-even:\n* положительный исход [![asciicast](https://asciinema.org/a/7Cqml07XyFin95eHZhplMMwNc.svg)](https://asciinema.org/a/7Cqml07XyFin95eHZhplMMwNc)\n* отрицательный исход [![asciicast](https://asciinema.org/a/SgfLkCaCYfbwnpSlUEF9QZU4v.svg)](https://asciinema.org/a/SgfLkCaCYfbwnpSlUEF9QZU4v)\n\nbrain-calc:\n* положительный исход [![asciicast](https://asciinema.org/a/Zl9AGfntR8t5jCqbhh3VVzVqP.svg)](https://asciinema.org/a/Zl9AGfntR8t5jCqbhh3VVzVqP)\n* отрицательный исход [![asciicast](https://asciinema.org/a/9Au3sYx03J8xox57RaqAzXZ9M.svg)](https://asciinema.org/a/9Au3sYx03J8xox57RaqAzXZ9M)\n\nbrain-gcd:\n* [![asciicast](https://asciinema.org/a/yJ3C0t5Fho4r14FQh6bxDOiys.svg)](https://asciinema.org/a/yJ3C0t5Fho4r14FQh6bxDOiys) - положительный исход\n* [![asciicast](https://asciinema.org/a/eI3zii85KQayTYb52rMXPO1wI.svg)](https://asciinema.org/a/eI3zii85KQayTYb52rMXPO1wI) - отрицательный исход\n\nbrain-progression:\n* [![asciicast](https://asciinema.org/a/R7teq5VSGFngBF7btJLVAWSgy.svg)](https://asciinema.org/a/R7teq5VSGFngBF7btJLVAWSgy) - положительный исход\n* [![asciicast](https://asciinema.org/a/87P1ddZglEURm1wjUSSjpPzOe.svg)](https://asciinema.org/a/87P1ddZglEURm1wjUSSjpPzOe) - отрицательный исход\n\nbrain-prime:\n* [![asciicast](https://asciinema.org/a/T5X193YT9CvIzQeZAfqR7duA8.svg)](https://asciinema.org/a/T5X193YT9CvIzQeZAfqR7duA8) - положительный исход\n- отрицательный исход',
    'author': 'DanciestDaisy',
    'author_email': 'ivan.berdigulov@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0',
}


setup(**setup_kwargs)
