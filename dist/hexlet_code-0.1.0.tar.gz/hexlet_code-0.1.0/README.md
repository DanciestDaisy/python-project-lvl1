### Hexlet tests and linter status:
[![Actions Status](https://github.com/DanciestDaisy/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/DanciestDaisy/python-project-lvl1/actions)

brain-even:
* положительный исход [![asciicast](https://asciinema.org/a/7Cqml07XyFin95eHZhplMMwNc.svg)](https://asciinema.org/a/7Cqml07XyFin95eHZhplMMwNc)
* отрицательный исход [![asciicast](https://asciinema.org/a/SgfLkCaCYfbwnpSlUEF9QZU4v.svg)](https://asciinema.org/a/SgfLkCaCYfbwnpSlUEF9QZU4v)

brain-calc:
* положительный исход [![asciicast](https://asciinema.org/a/Zl9AGfntR8t5jCqbhh3VVzVqP.svg)](https://asciinema.org/a/Zl9AGfntR8t5jCqbhh3VVzVqP)
* отрицательный исход [![asciicast](https://asciinema.org/a/9Au3sYx03J8xox57RaqAzXZ9M.svg)](https://asciinema.org/a/9Au3sYx03J8xox57RaqAzXZ9M)

brain-gcd:
* [![asciicast](https://asciinema.org/a/yJ3C0t5Fho4r14FQh6bxDOiys.svg)](https://asciinema.org/a/yJ3C0t5Fho4r14FQh6bxDOiys) - положительный исход
* [![asciicast](https://asciinema.org/a/eI3zii85KQayTYb52rMXPO1wI.svg)](https://asciinema.org/a/eI3zii85KQayTYb52rMXPO1wI) - отрицательный исход

brain-progression:
* [![asciicast](https://asciinema.org/a/R7teq5VSGFngBF7btJLVAWSgy.svg)](https://asciinema.org/a/R7teq5VSGFngBF7btJLVAWSgy) - положительный исход
* [![asciicast](https://asciinema.org/a/87P1ddZglEURm1wjUSSjpPzOe.svg)](https://asciinema.org/a/87P1ddZglEURm1wjUSSjpPzOe) - отрицательный исход

brain-prime:
* [![asciicast](https://asciinema.org/a/T5X193YT9CvIzQeZAfqR7duA8.svg)](https://asciinema.org/a/T5X193YT9CvIzQeZAfqR7duA8) - положительный исход
- отрицательный исход